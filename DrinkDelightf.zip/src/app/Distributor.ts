export class Distributor{
    distributorId:String;
    name:string;
    Address:string;
    phoneNumber:number;
 
}
