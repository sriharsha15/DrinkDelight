import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { AddDistributorComponent } from './AddDist/add-distributor/add-distributor.component';
import { DisplayDistributorComponent } from './DistDetails/display-distributor/display-distributor.component';


const routes: Routes = [{ path: 'add', component: AddDistributorComponent },
{ path: 'display', component: DisplayDistributorComponent },
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
