import { Component, OnInit } from '@angular/core';
import { Distributor } from 'src/app/Distributor';
import { DistributorService } from 'src/app/distributor.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-display-distributor',
  templateUrl: './display-distributor.component.html',
  styleUrls: ['./display-distributor.component.css']
})
export class DisplayDistributorComponent implements OnInit {


  distributors: Distributor[] = [];
  sear:boolean=false
  
 // distributor: Distributor = new Distributor();
 
  constructor(private distributorservice: DistributorService) { }

   
  search(){
    this.sear=true;
  }
  ngOnInit() {
        this.distributorservice.loadDistributor().subscribe(data => {
          this.distributors = data;
          //this.distributorservice.setDistributor(this.distributor);
        });
  }
}
