import { Component, OnInit } from '@angular/core';
import { Distributor } from 'src/app/Distributor';
import { DistributorService } from 'src/app/distributor.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-add-distributor',
  templateUrl: './add-distributor.component.html',
  styleUrls: ['./add-distributor.component.css']
})
export class AddDistributorComponent implements OnInit {
   distributor: Distributor = new Distributor();

  constructor(private distributorservice: DistributorService, private route: Router) { }

  ngOnInit(): void {
  }
  addDistributor() {
    console.log("add Distributor");
    this.distributorservice.insertDistributor(this.distributor).subscribe(data=>{this.distributor=data});
    this.route.navigateByUrl("/display");
  }
}
