import { Injectable } from '@angular/core';
import { Distributor } from './Distributor';
import { Observable } from 'rxjs';
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class DistributorService {

 
  private distributor: Distributor[]=[];
  //flag:boolean=false;
  constructor(private http: HttpClient) {}
  

 
  loadDistributor():Observable<any>{

    return this.http.get("http://localhost:8096/getdistributor");
  }

  
  setDistributor(distributor:Distributor[]):void {
    this.distributor=distributor;
  }

 
  getDistributor():Distributor[]{
    return this.distributor;
  }

  
  insertDistributor(distributor:Distributor):Observable<any>{
   
    return this.http.post("http://localhost:8096/distributor",distributor,{responseType:"text"});
  }
 
}
