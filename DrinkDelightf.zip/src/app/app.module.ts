import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import {HttpClientModule} from '@angular/common/http';
import {FormsModule} from '@angular/forms';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { AddDistributorComponent } from './AddDist/add-distributor/add-distributor.component';
import { DisplayDistributorComponent } from './DistDetails/display-distributor/display-distributor.component';
import { DistributorService } from './distributor.service';

@NgModule({
  declarations: [
    AppComponent,
    AddDistributorComponent,
    DisplayDistributorComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    HttpClientModule,
    FormsModule
  ],
  providers: [DistributorService],
  bootstrap: [AppComponent]
})
export class AppModule { }
